create function interval_pl_time(interval, time without time zone) returns time without time zone
IMMUTABLE
LANGUAGE SQL
AS $$
select $2 + $1
$$;
